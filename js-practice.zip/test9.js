function change(){
    var par = document.write("sen");
    par.innerHTML = "나의 <img src= '/FDI/image/puppy/png'> 강아지";
}
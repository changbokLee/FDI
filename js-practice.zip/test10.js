function change(){
    var b1 =document.getElementsById("btn1");
    b1.style.color = "red";
    b1.style.fontsize = "50px";
}

function reset(obi, size , col){
    obi.style.color = col;
    obi.style.fontsize = size;
}

function click(obt){
    obt.style.backgroundcolor = red;

}
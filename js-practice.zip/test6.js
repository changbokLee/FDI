var arr = ["김밥", " 짜장면", "떡볶이", "라면", "우동", "국밥"];
document.writue("<ul>");

for(var i =0; i< arr.length; i++){
    document.write(menu[i]);
}

document.write("<ul>");


function change(){
    var tmp = document.getElementById("my");
    tmp.style.color = "green";
    tmp.style.fontSize ="20px";
    tmp.style.border = "3px dotted";
}
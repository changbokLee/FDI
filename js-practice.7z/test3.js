var num = 0;
function cal(){
    num++;
    document.write(num , "<br>");

}
cal()
cal()